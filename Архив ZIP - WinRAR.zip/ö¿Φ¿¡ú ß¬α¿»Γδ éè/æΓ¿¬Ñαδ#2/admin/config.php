<?php 
	$adminlogin = 'admin'; // Вместо admin пишем желаемый логин для админ панели
	$adminpassw = 'panel228'; // Вместо panel пишем желаемый пароль для админ панели
?>
